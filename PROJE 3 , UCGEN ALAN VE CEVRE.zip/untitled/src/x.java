import java.util.Scanner;
public class x {
    public static void main(String[] args) {
        double a , b ,c,u;
        Scanner x = new Scanner(System.in);
        System.out.println("Uyari ondalikli ifadelerde nokta kullanmayiniz.");
        System.out.print("1. kenar degerini giriniz : ");
        a = x.nextDouble();
        System.out.print("2. kenar degerini giriniz : ");
        b = x.nextDouble();
        System.out.print("3. kenar degerini giriniz : ");
        c = x.nextDouble();
        u = (a + b + c)/2;
        System.out.println("Ucgenimizin cevresi : " + 2* u );
        System.out.println("Ucgenimizin alani : " + Math.sqrt(u*(u - a)*(u - b)*(u - c)));
    }

}