import java.util.Scanner;
public class x {
    public static void main(String[] args) {
        System.out.println("Kombinsayon hesaplama programina hosgeldiniz ");
        Scanner input = new Scanner(System.in);
        System.out.print("Hangi sayinin kombinasyonunu alicaksiniz : ");
        int n = input.nextInt(),fakt = 1 , fakt1= 1, fakt2 = 1;
        System.out.print("Hangi sayili kombinasyonu alicaksin : ");
        int r = input.nextInt();

        for(int i = 1 ; i <=n ; i++){
            fakt = fakt*i;
        }
        for(int i = 1; i<=r ; i ++){
            fakt1 = fakt1*i;
        }
        for(int i =1 ; i<=(n-r); i++)
            fakt2 = fakt2*i;
        System.out.print("Kombinasyon degeriniz : " + fakt/(fakt1*fakt2));
    }
}