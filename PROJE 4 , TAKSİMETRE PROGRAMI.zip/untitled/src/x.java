import java.util.Scanner;
public class x {
    public static void main(String[] args) {
        int km ;
        Scanner input = new Scanner(System.in);
        System.out.print("Gidilecek yolu km cinsinden yaziniz:");
        km = input.nextInt();
        double a ,b ;
        b = km*2.20;
        b = b*2.20<10 ? 10 : b*2.20;
        a = 10 + b;
        System.out.println(a);
    }
}