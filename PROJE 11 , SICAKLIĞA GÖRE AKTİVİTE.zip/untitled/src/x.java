import java.util.Scanner;
public class x {
    public static void main(String[] args) {
        int sicaklik;
        Scanner hava = new Scanner(System.in);
        System.out.println("HAVA KAC DERECE ? ");
        sicaklik = hava.nextInt();
        if(sicaklik<5){
            System.out.println("KAYAK YAPMAYA NE DERSIN ? ");
        }else if((5<=sicaklik)&&(sicaklik<15)){
            System.out.println("SINEMAYA GITMEYE NE DERSIN ? ");
        }else if((15<=sicaklik)&&(sicaklik<25)){
            System.out.println("PIKNIGE GITMEYE NE DERSIN ? ");
        }else if((25<=sicaklik)&&(sicaklik<40)){
            System.out.println("YUZMEYE GITMEYE NE DERSIN ? ");
        }else if(40 <= sicaklik){
            System.out.println("BU SICAKLIK INSAN SAGLIGI ICIN TEHLIKELIDIR. OTUR EVINDE!!!");
        }
    }
}



