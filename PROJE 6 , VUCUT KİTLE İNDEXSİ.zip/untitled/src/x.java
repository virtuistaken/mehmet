import jdk.swing.interop.SwingInterOpUtils;

import java.util.Scanner;
public class x {
    public static void main(String[] args) {
        double kilo , boy , index ;
        Scanner input = new Scanner(System.in);
        System.out.println("VUCUT KITLE INDEKSI HESAPLAMA PROGRAMIMIZA HOSGELDINIZ");
        System.out.println("Boyunuzu giriniz(metre) : ");
        boy = input.nextDouble();
        System.out.println("Kilonuzu giriniz(kg) : ");
        kilo = input.nextDouble();
        index = kilo / (boy * boy);
        System.out.println("Vucut kitle indexiniz : " + index);


    }



}