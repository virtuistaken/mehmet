import java.util.Scanner;
public class x {
    public static void main(String[] args) {
        /*
            Java ile kullanıcıdan alınan para değerinin KDV'li fiyatını ve KDV tutarını hesaplayıp ekrana bastıran
            programı yazın.
            Eğer girilen tutar 0 ve 1000 TL arasında ise KDV oranı %18 , tutar 1000 TL'den büyük ise KDV oranını %8
            olarak KDV tutarı hesaplayan programı yazınız.
         */
        double a;
        Scanner x = new Scanner(System.in);
        System.out.print("URUN FIYATINI GIRINIZ:");
        a = x.nextInt();
        double b = 1000, c = 0;

        double kdv = (c<a)&&(a<=b) ? 0.18 : 0.08 ;
        double m = a + a*kdv;

        System.out.println("KDV oraniniz : " + kdv);
        System.out.println("KDV'li fiyatiniz : " + m);
        System.out.println("KDV'siz fiyatiniz : " + a);


    }
}
