import java.util.Scanner;

public class x{
    public static void main(String[] args) {

        Scanner x = new Scanner(System.in);

        int yas, km ,tip ;
        System.out.print("Yasinizi giriniz : ");
        yas = x.nextInt();
        System.out.print("Gideceginiz yol kac km : ");
        km = x.nextInt();
        System.out.println("Hangi yolculuk tipini seciceksiniz ?\n1-Tek Yon\n2-Gidis Donus");
        tip = x.nextInt();

        double yolKm;
        yolKm = km * 0.1;
        if(km<0){
            System.out.println("Hatali Veri Girdiniz !!!");
        }else{
            if(yas<=0){
                System.out.println("Hatali Veri Girdiniz !!!");
            }else{
                if((tip == 1) ||(tip == 2)){
                    if (yas<12){
                        switch(tip){
                            case 1:
                                System.out.println(yolKm/2);
                                break;
                            case 2:
                                System.out.println((yolKm/4*10)*2);
                                break;
                        }

                    }else if((12<=yas)&&(yas<=24)){
                        switch (tip){
                            case 1:
                                System.out.println((yolKm/10)*9);
                                break;
                            case 2:
                                System.out.println(((yolKm/100)*72)*2);
                                break;
                        }

                    }else if((65<=yas)){
                        switch (tip){
                            case 1:
                                System.out.println((yolKm/10)*7);
                                break;
                            case 2:
                                System.out.println(((yolKm*56)/100)*2);
                                break;
                        }

                    }else{
                        switch (tip){
                            case 1:
                                System.out.println(yolKm);
                                break;
                            case 2:
                                System.out.println(((yolKm*8)/10)*2);
                                break;
                        }

                    }
                }else{
                    System.out.println("Hatali Veri Girdiniz !!!");
                }
            }
        }




    }
}