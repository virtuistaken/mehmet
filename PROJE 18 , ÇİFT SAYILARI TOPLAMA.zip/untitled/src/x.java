import java.util.Scanner;

public class x {
    public static void main(String[] args) {
        int x = 0;
        int toplam = 0 ;
        Scanner input = new Scanner(System.in);

        do{
            System.out.print("Sayi giriniz : ");
            x =input.nextInt();
            if (x % 2 == 0){
                toplam += x;
            }
        }while (x % 2 == 0 );
        System.out.println("Toplam : " + toplam);
    }
}
