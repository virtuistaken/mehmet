import java.util.Scanner;

public class x {
    public static void main(String[] args) {
        double mat, tr, fizik, kimya, muzik;
        Scanner scr = new Scanner(System.in);
        System.out.println("Sinif GECME/KALMA bilgisi veren programimiza hosgeldiniz");
        System.out.println("Matematik notunuzu giriniz : ");
        mat = scr.nextDouble();
        if (mat < 0) {
            System.out.println("Hatali giris !!");
        } else if (100 < mat) {
            System.out.println("Hatali giris !!");
        } else {
            System.out.println("Turkce notunuzu giriniz : ");
            tr = scr.nextDouble();
            if (tr < 0) {
                System.out.println("Hatali giris !!");
            } else if (100 < tr) {
                System.out.println("Hatali giris !!");
            } else {
                System.out.println("Fizik notunuzu giriniz : ");
                fizik = scr.nextDouble();
                if (fizik < 0) {
                    System.out.println("Hatali giris !!");

                } else if (100 < fizik) {
                    System.out.println("Hatali giris !!");
                } else {
                    System.out.println("Kimya notunuzu giriniz : ");
                    kimya = scr.nextDouble();
                    if (kimya < 0) {
                        System.out.println("Hatali giris !!");
                    } else if (100 < kimya) {
                        System.out.println("Hatali giris !!");
                    } else {
                        System.out.println("Muzik notunuzu giriniz : ");
                        muzik = scr.nextDouble();
                        if (muzik < 0) {
                            System.out.println("Hatali giris !!");

                        } else if (100 < muzik) {
                            System.out.println("Hatali giris !!");
                        } else {
                            double ortalama;
                            ortalama = (mat * 6 + tr * 5 + fizik * 4 + kimya * 4 + muzik * 1) / 20;
                            System.out.println("ORTALAMANIZ : " + ortalama);

                            if (ortalama < 55) {
                                System.out.println("KALDINIZ !!!");
                            } else {
                                System.out.println("GECTINIZ TEBRIKLER");
                            }
                        }
                    }
                }
            }
        }
    }
}



