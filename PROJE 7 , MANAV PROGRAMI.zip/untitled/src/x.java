import jdk.swing.interop.SwingInterOpUtils;

import java.util.Scanner;
public class x {
    public static void main(String[] args) {
        double armut ,elma , domates ,muz , patlican ,total ;
        Scanner input = new Scanner(System.in);
        System.out.println("MARKETIMIZE HOSGELDINIZ");
        System.out.println("Satin aldiginiz armutu kg cinsinden yaziniz : ");
        armut = input.nextDouble();
        System.out.println("Satin aldiginiz elmayi kg cinsinden yaziniz : ");
        elma = input.nextDouble();
        System.out.println("Satin aldiginiz domatesi kg cinsinden yaziniz : ");
        domates = input.nextDouble();
        System.out.println("Satin aldiginiz muzu kg cinsinden yaziniz : ");
        muz = input.nextDouble();
        System.out.println("Satin aldiginiz patlicani kg cinsinden yaziniz : ");
        patlican = input.nextDouble();
        total = armut* 2.14 + elma * 3.67 + domates * 1.11 + muz* 0.95 + patlican * 5 ;
        System.out.println("Toplam tutar : " + total);

    }



}