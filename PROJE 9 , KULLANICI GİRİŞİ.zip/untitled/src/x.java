import java.util.Scanner;

public class x {
    public static void main(String[] args) {
        String kullaniciAdi, sifre;
        Scanner x = new Scanner(System.in);
        System.out.print("Kullanici adinizi giriniz : ");
        kullaniciAdi = x.nextLine();

        if (kullaniciAdi.equals("Mehmet000")) {


            System.out.print("Sifrenizi giriniz : ");
            sifre = x.nextLine();

            if (sifre.equals("000mehmet")) {
                System.out.println("Giris Basarili");
            } else {
                System.out.println("Sifreniz yanlistir.");
                System.out.println("Sifrenizi yenilemek ister misiniz ? ");
                String yeniSifre , cevap ;
                cevap = x.nextLine();
                if(cevap.equals("evet")) {
                    System.out.print("Degistirmek Istediginiz Sifreyi Giriniz : ");
                    yeniSifre = x.nextLine();
                    if (yeniSifre.equals("000mehmet")) {
                        System.out.println("Yeni Sifre eskisi ile ayni olamaz !!!");
                    } else {
                        System.out.println("Sifreniz Basari Ile Degistirilmistir");
                    }
                }else{
                    System.out.println("Daha sonra yine bekleriz");
                }
            }
            } else {
                System.out.println("Kullanici adiniz yanlistir.");
                System.out.println("");
        }
    }
}
