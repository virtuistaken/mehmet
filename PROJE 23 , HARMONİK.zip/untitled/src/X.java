import java.util.Scanner;

public class X {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Sayi giriniz : ");
        double sayi = input.nextInt();
        double sonuc = 0;
        double deger = 0;
        for (int i = 1; i <= sayi; i++) {
            deger = 1.0/i;
            sonuc += deger;
        }
        System.out.println(sonuc);
    }
}