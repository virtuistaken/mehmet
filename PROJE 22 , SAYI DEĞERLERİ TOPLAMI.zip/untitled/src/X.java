import java.util.Scanner;

public class X {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Bir sayi giriniz : ");
        int istenenSayi = input.nextInt();
        int sonuc = 0;
        int deger ;
        int temp = istenenSayi;
        while (temp != 0) {
            deger = temp % 10;
            temp /= 10;

            sonuc +=deger ;
        }
        System.out.println(sonuc);
    }
}