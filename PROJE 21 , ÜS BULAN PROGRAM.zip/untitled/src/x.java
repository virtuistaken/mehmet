import java.util.Scanner;

public class x {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int us, kuvvet;
        System.out.print("Us degerini giriniz : ");
        us = input.nextInt();
        System.out.print("Kuvvet degerini giriniz : ");
        kuvvet = input.nextInt();
        int sonuc =1 ;
        for (int i = 1; i <= kuvvet; i++) {

            sonuc = us * sonuc;

        }
        System.out.print("CEVAP : " + sonuc);
    }

}