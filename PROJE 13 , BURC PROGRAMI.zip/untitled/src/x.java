import java.util.Scanner;
public class x {
    public static void main(String[] args) {
        Scanner giris = new Scanner(System.in);
        int day, ay;
        System.out.print("DOGDUGUNUZ GUNUN NUMARASINI YAZINIZ : ");
        day = giris.nextInt();

        if (32 <= day) {
            System.out.println("HATALI GIRIS");
        }else{
            System.out.print("DOGDUGUNUZ AYIN NUMARASINI YAZINIZ : ");
            ay = giris.nextInt();
            switch (ay) {
                case 1:
                    if (day <= 21) {
                        System.out.println("OGLAK");
                    } else {
                        System.out.println("KOVA");
                    }
                    break;
                case 2:
                    if (day <= 19) {
                        System.out.println("KOVA");
                    } else {
                        System.out.println("BALIK");
                    }
                    break;
                case 3:
                    if (day <= 20) {
                        System.out.println("BALIK");
                    } else {
                        System.out.println("KOC");
                    }
                    break;
                case 4:
                    if (day <= 20) {
                        System.out.println("KOC");
                    } else {
                        System.out.println("BOGA");
                    }
                    break;
                case 5:
                    if (day <= 21) {
                        System.out.println("BOGA");
                    } else {
                        System.out.println("IKIZLER");
                    }
                    break;
                case 6:
                    if (day <= 22) {
                        System.out.println("IKIZLER");
                    } else {
                        System.out.println("YENGEC");
                    }
                    break;
                case 7:
                    if (day <= 22) {
                        System.out.println("YENGEC");
                    } else {
                        System.out.println("ASLAN");
                    }
                    break;
                case 8:
                    if (day <= 22) {
                        System.out.println("ASLAN");
                    } else {
                        System.out.println("BASAK");
                    }
                    break;
                case 9:
                    if (day <= 22) {
                        System.out.println("BASAK");
                    } else {
                        System.out.println("TERAZI");
                    }
                    break;
                case 10:
                    if (day <= 22) {
                        System.out.println("TERAZI");
                    } else {
                        System.out.println("AKREP");
                    }
                    break;
                case 11:
                    if (day <= 21) {
                        System.out.println("AKREP");
                    } else {
                        System.out.println("YAY");
                    }
                    break;
                case 12:
                    if (day <= 21) {
                        System.out.println("YAY");
                    } else {
                        System.out.println("OGLAK");
                    }
                    break;
                default:
                    System.out.println("HATALI GIRIS");

            }
        }
    }
}