import java.util.Scanner;

public class x {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Girilen sayidan kucuk 4 ve 5 in  kuvvetlerini veren programa hosgeldiniz");
        System.out.print("Bir sayi giriniz : ");
        int sayi = input.nextInt();
        System.out.println("4'un kuvvetleri");
        for (int i = 1; i <= sayi; i *= 4) {
            System.out.println(i);

        }
        System.out.println("5' in kuvvetleri");
        for (int i =1 ; i <= sayi; i*=5 ){
            System.out.println(i);
        }
    }
}