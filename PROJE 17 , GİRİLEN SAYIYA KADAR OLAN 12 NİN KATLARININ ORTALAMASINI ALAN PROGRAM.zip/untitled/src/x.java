import java.util.Scanner;

public class x{
    public static void main(String[] args) {
        int i ,toplam=0,parca=0;
        Scanner input = new Scanner(System.in);

        System.out.print("Sayi Giriniz : ");
        i = input.nextInt();
        for(int k = 1 ; k<=i; k++){

            if(k%12==0){
                toplam += k;
                parca++;

            }
        }

        double ortalama = toplam/(parca);
        System.out.println("ortalama : " + ortalama);
    }
}

