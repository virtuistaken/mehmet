import java.util.Scanner;

public class x {
    public static void main(String[] args) {
        double n1, n2;
        int select;
        Scanner x = new Scanner(System.in);
        System.out.println("1. Sayiyi Giriniz : ");
        n1 = x.nextDouble();
        System.out.println("2. Sayiyi Giriniz : ");
        n2 = x.nextDouble();
        System.out.println("1- Toplama \n2- Cikarma \n3- Carpma \n4- Bolme ");
        select = x.nextInt();

        switch (select) {

            case 1:
                System.out.println(n1 + n2);
                break;
            case 2:
                System.out.println(n1 - n2);
                break;
            case 3:
                System.out.println(n1 * n2);
                break;
            case 4:
                switch ((int) n2) {
                    case 0:
                        System.out.println("Bir sayi sifira bolunumez !!!");
                        break;
                    default:
                        System.out.println(n1 / n2);
                }
                break;
            default:
                System.out.println("Hatali giris !!! ");
        }
    }
}