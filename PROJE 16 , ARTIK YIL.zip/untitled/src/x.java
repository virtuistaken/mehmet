import java.util.Scanner;
public class x{
    public static void main(String[] args) {
        int yil,kalan;
        Scanner x = new Scanner(System.in);
        System.out.println("YILI GIRINIZ");
        yil = x.nextInt();
        kalan = yil%4;
        switch (kalan){
            case 0:
                System.out.println(yil+" ARTIK YILDIR");
                break;
            default:
                System.out.println(yil + " ARTIK YIL DEGILDIR");
        }
    }
}