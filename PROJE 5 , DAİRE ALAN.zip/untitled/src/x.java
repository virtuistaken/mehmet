import java.util.Scanner;
public class x {
    public static void main(String[] args) {
        double r , pi ;
        Scanner x = new Scanner(System.in);
        System.out.print("Alanini ve cevresini istediginiz dairenin yaricapini giriniz : ");
        r = x.nextDouble();
        System.out.print("istediginiz aci degerini de giriniz : ");
        double alan , cevre , acı ;
        acı = x.nextDouble();
        pi = 3.14;
        alan = pi*r*r*acı/360;
        System.out.println("Alaniniz : " + alan);


    }
}